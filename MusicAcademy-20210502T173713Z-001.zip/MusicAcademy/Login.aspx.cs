﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace MusicAcademy
{
    public partial class Login : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-U1GMOQV;Initial Catalog=MusicDb;Integrated Security=True");
        SqlCommand query;
        SqlDataReader reader;
        ConnectionState state = new ConnectionState();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String User = TextBox1.Text.Trim();
            String Password = TextBox2.Text.Trim();
            String U = "", P = "";
            String Name = "";
            int id = 0;
            if (DropDownList1.SelectedItem.Text.Trim().Equals("Admin"))
            {
                if (TextBox1.Text.Trim().Equals("Shubham") && TextBox2.Text.Trim().Equals("admin"))
                    Response.Redirect("~/Aindex.aspx");

                else
                {
                    Response.Write("<script>alert('Invalid Admin!!!..')</script>");
                    TextBox1.Text = "";
                    TextBox2.Text = "";
                    TextBox1.Focus();
                }
            }
            else
            {
                if (state == ConnectionState.Open)
                    conn.Close();
                else
                {
                    conn.Open();
                    query = new SqlCommand("Select * from tbl_Stud where UName='" + TextBox1.Text.Trim() + "'", conn);
                    reader = query.ExecuteReader();
                    while (reader.Read())
                    {
                        U = reader[0].ToString();
                        P = reader[1].ToString();
                        Name = reader[2].ToString();

                    }
                    reader.Close();
                    conn.Close();
                }


                if (TextBox1.Text.Trim().Equals(U) && TextBox2.Text.Trim().Equals(P))
                {
                    Session["Name"] = Name;
                    Session["UName"] = U;

                    Response.Redirect("~/Sindex.aspx");

                }
                else
                {
                    Response.Write("<script>alert('Invalid User Id!!!..')</script>");
                    TextBox1.Text = "";
                    TextBox2.Text = "";
                    TextBox1.Focus();
                }


            }
        }
    }
}