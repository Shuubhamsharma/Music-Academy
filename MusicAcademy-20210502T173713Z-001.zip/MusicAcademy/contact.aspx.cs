﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace MusicAcademy
{
    public partial class contact : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-U1GMOQV;Initial Catalog=MusicDb;Integrated Security=True");
        SqlCommand query;
        SqlDataReader reader;
        ConnectionState state = new ConnectionState();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (state == ConnectionState.Open)
                conn.Close();
            else
            {
                conn.Close();
                conn.Open();
                query = new SqlCommand("insert into tbl_Contact values('" + Request.Form["Name"] + "','" + Request.Form["Cont"] + "','" + Request.Form["Email"] + "','" + Request.Form["Message"] + "')", conn);
                reader = query.ExecuteReader();
                Response.Write("<script>alert('Message Send..')</script>");
                reader.Close();
            }
        }
    }
}