﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace MusicAcademy
{
    public partial class ViewP : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-U1GMOQV;Initial Catalog=MusicDb;Integrated Security=True");
        SqlCommand query;
        SqlDataReader reader;
        ConnectionState state = new ConnectionState();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (state == ConnectionState.Open)
                conn.Close();
            else
            {
                conn.Open();
                query = new SqlCommand("Select Distinct Music_Form from tbl_Sch", conn);
                reader = query.ExecuteReader();
                while (reader.Read())
                    DropDownList1.Items.Add(reader[0].ToString());
                reader.Close();
                conn.Close();
            }
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {


            if (state == ConnectionState.Open)
                conn.Close();
            else
            {
                conn.Open();
                query = new SqlCommand("Select * from tbl_Sch where Music_Form='" + DropDownList1.SelectedItem.Text.Trim() + "'", conn);
                reader = query.ExecuteReader();
                while (reader.Read())
                    DropDownList2.Items.Add(reader[8].ToString());
                reader.Close();
                conn.Close();
            }



            
        }

        protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
        {
            Label3.Visible = true;
            if (DropDownList3.SelectedItem.Text.Equals("Cash on Arrival"))
            {
                Panel2.Visible = true;
                Panel2.Visible = false;
            }
            else
            {
                Panel2.Visible = false;
                Panel2.Visible = true;
                if (DropDownList3.SelectedItem.Text.Equals("Credit Card"))

                    Label3.Text = "Credit Card";
                else
                    Label3.Text = "Debit Card";
            }
        }

        protected void Button3_Click1(object sender, EventArgs e)
        {
            if (state == ConnectionState.Open)
                conn.Close();
            else
            {
                conn.Open();
                query = new SqlCommand("Select * from tbl_Sch where Music_Form='" + DropDownList1.SelectedItem.Text.Trim() + "' and Timing='" + DropDownList2.SelectedItem.Text.Trim() + "'", conn);
                reader = query.ExecuteReader();
                while (reader.Read())
                {
                    TextBox9.Text = reader[1].ToString();
                    TextBox2.Text = reader[2].ToString();
                    TextBox4.Text = reader[5].ToString();
                    TextBox1.Text = reader[6].ToString();
                    TextBox7.Text = reader[7].ToString();                   

                }
                reader.Close();
                conn.Close();
            }
        }

          protected void Button4_Click1(object sender, EventArgs e)
        {

            String N = "";


            if (state == ConnectionState.Open)
                conn.Close();
            else
            {
                conn.Open();
                query = new SqlCommand("Select * from tbl_JStud", conn);
                reader = query.ExecuteReader();
                while (reader.Read())
                   N=reader[0].ToString();
                reader.Close();
                conn.Close();
            }



            if (N.Equals(Session["UName"].ToString()))
            {

                try
                {

                    if (state == ConnectionState.Open)
                        conn.Close();
                    else
                    {
                        conn.Close();
                        conn.Open();
                        query = new SqlCommand("Update tbl_JStud set Paid=Paid+'"+TextBox3.Text.Trim()+"',Date='"+System.DateTime.Now.ToShortDateString()+"' where Student_Id='"+Session["UName"].ToString()+"'", conn);
                        reader = query.ExecuteReader();
                        lblMessage.Visible = true;
                        reader.Close();
                        lblMessage.Text = "Recods Updated Successfully..";
                    }

                    TextBox3.Text = "";
                    TextBox2.Text = "";
                    TextBox4.Text = "";
                    TextBox7.Text = "";
                    TextBox9.Text = "";
                    TextBox1.Text = "";
                    TextBox10.Text = "";
                    TextBox5.Text = "";
                    DropDownList1.SelectedItem.Text = "--Select--";
                    DropDownList2.SelectedItem.Text = "--Select--";
                    DropDownList3.SelectedItem.Text = "--Select--";
                    DropDownList1.Focus();

                }
                finally
                {
                    conn.Close();
                }

            }






            else
            {

                try
                {

                    if (state == ConnectionState.Open)
                        conn.Close();
                    else
                    {
                        conn.Close();
                        conn.Open();
                        query = new SqlCommand("insert into tbl_JStud values('" + Session["UName"].ToString() + "','" + DropDownList1.SelectedItem.Text.Trim() + "','" + DropDownList2.SelectedItem.Text.Trim() + "','" + TextBox3.Text.Trim() + "','" + System.DateTime.Now.ToShortDateString() + "','" + TextBox10.Text.Trim() + "','" + TextBox5.Text.Trim() + "')", conn);
                        reader = query.ExecuteReader();
                        lblMessage.Visible = true;
                        reader.Close();
                        lblMessage.Text = "Recods Inserted Successfully..";
                    }

                    TextBox3.Text = "";
                    TextBox2.Text = "";
                    TextBox4.Text = "";
                    TextBox7.Text = "";
                    TextBox9.Text = "";
                    TextBox1.Text = "";
                    TextBox10.Text = "";
                    TextBox5.Text = "";
                    DropDownList1.SelectedItem.Text = "--Select--";
                    DropDownList2.SelectedItem.Text = "--Select--";
                    DropDownList3.SelectedItem.Text = "--Select--";
                    DropDownList1.Focus();

                }
                finally
                {
                    conn.Close();
                }

            }

        }

          protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
          {

          }
    }
}