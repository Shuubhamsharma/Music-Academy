﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace MusicAcademy
{
    public partial class US : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-U1GMOQV;Initial Catalog=MusicDb;Integrated Security=True");
        SqlCommand query;
        SqlDataReader reader;
        ConnectionState state = new ConnectionState();
        protected void Page_Load(object sender, EventArgs e)
        {
            TextBox1.Text = Session["UName"].ToString();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox4.Text = "";
            TextBox7.Text = "";
            TextBox8.Text = "";
            TextBox9.Text = "";
            TextBox9.Focus();
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            if (state == ConnectionState.Open)
                conn.Close();
            else
            {
                conn.Open();
                query = new SqlCommand("Select * from tbl_Stud where UName='" + TextBox1.Text.Trim() + "'", conn);
                reader = query.ExecuteReader();
                while (reader.Read())
                {
                    TextBox9.Text = reader[1].ToString();
                    TextBox7.Text = reader[2].ToString();
                    TextBox2.Text = reader[3].ToString();                    
                    TextBox8.Text = reader[5].ToString();
                    TextBox4.Text = reader[6].ToString();
                    
                    byte[] img = (byte[])(reader[4]);
                    if (img == null)
                    {
                        Image1.ImageUrl = null;
                    }

                    else
                    {
                        string base64String = Convert.ToBase64String(img, 0, img.Length);
                        Image1.ImageUrl = "data:image/jpg;base64," + base64String; ;
                    }


                }
                reader.Close();
                conn.Close();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {

                if (state == ConnectionState.Open)
                    conn.Close();
                else
                {
                    conn.Close();
                    conn.Open();
                    query = new SqlCommand("Update tbl_Stud set Name='" + TextBox7.Text.Trim() + "',Mobile='" + TextBox2.Text.Trim() + "',Age='" + TextBox8.Text.Trim() + "', Email_Id='" + TextBox4.Text.Trim() + "' Where UName='" + TextBox1.Text.Trim() + "'", conn);
                    reader = query.ExecuteReader();
                    Response.Write("<script>alert('Records Updated!!!!');</script>");
                    reader.Close();
                }

            }
            finally
            {
                conn.Close();
            }
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox4.Text = "";
            TextBox7.Text = "";
            TextBox8.Text = "";
            TextBox9.Text = "";            
            TextBox9.Focus();
        }
    }
}