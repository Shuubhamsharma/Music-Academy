﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace MusicAcademy
{
    public partial class RSch : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-U1GMOQV;Initial Catalog=MusicDb;Integrated Security=True");
        SqlCommand query;
        SqlDataReader reader;
        ConnectionState state = new ConnectionState();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (state == ConnectionState.Open)
                conn.Close();
            else
            {
                conn.Open();
                query = new SqlCommand("Select Distinct Music_Form from tbl_Sch", conn);
                reader = query.ExecuteReader();
                while (reader.Read())
                    DropDownList1.Items.Add(reader[0].ToString());
                reader.Close();
                conn.Close();
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            DropDownList1.SelectedItem.Text = "--Select--";
            DropDownList2.SelectedItem.Text = "--Select--";
            TextBox2.Text = "";
            TextBox4.Text = "";
            TextBox7.Text = "";
            TextBox8.Text = "";
            TextBox9.Text = "";
            TextBox1.Text = "";
            DropDownList1.Focus();
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (state == ConnectionState.Open)
                conn.Close();
            else
            {
                conn.Open();
                query = new SqlCommand("Select * from tbl_Sch where Music_Form='" + DropDownList1.SelectedItem.Text.Trim() + "'", conn);
                reader = query.ExecuteReader();
                while (reader.Read())
                    DropDownList2.Items.Add(reader[8].ToString());
                reader.Close();
                conn.Close();
            }
        }

        protected void Button3_Click1(object sender, EventArgs e)
        {
            if (state == ConnectionState.Open)
                conn.Close();
            else
            {
                conn.Open();
                query = new SqlCommand("Select * from tbl_Sch where Music_Form='" + DropDownList1.SelectedItem.Text.Trim() + "' and Timing='" + DropDownList2.SelectedItem.Text.Trim() + "'", conn);
                reader = query.ExecuteReader();
                while (reader.Read())
                {
                    TextBox9.Text = reader[1].ToString();
                    TextBox2.Text = reader[2].ToString();
                    TextBox8.Text = reader[4].ToString();
                    TextBox4.Text = reader[5].ToString();
                    TextBox1.Text = reader[6].ToString();
                    TextBox7.Text = reader[7].ToString();

                    byte[] img = (byte[])(reader[3]);
                    if (img == null)
                    {
                        Image1.ImageUrl = null;
                    }

                    else
                    {
                        string base64String = Convert.ToBase64String(img, 0, img.Length);
                        Image1.ImageUrl = "data:image/jpg;base64," + base64String; ;
                    }


                }
                reader.Close();
                conn.Close();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {

                if (state == ConnectionState.Open)
                    conn.Close();
                else
                {
                    conn.Close();
                    conn.Open();
                    query = new SqlCommand("Delete From tbl_Sch Where Music_Form='" + DropDownList1.SelectedItem.Text.Trim() + "' and Timing='" + DropDownList2.SelectedItem.Text.Trim() + "'", conn);
                    reader = query.ExecuteReader();
                    lblMessage.Visible = true;
                    reader.Close();
                    lblMessage.Text = "Recods Removed succesfully...";
                }
            }
            finally
            {
                conn.Close();
            }
        }
    }
}