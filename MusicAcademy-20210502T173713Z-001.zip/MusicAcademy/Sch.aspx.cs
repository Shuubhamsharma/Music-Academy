﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace MusicAcademy
{
    public partial class Sch : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-U1GMOQV;Initial Catalog=MusicDb;Integrated Security=True");
        SqlCommand query;
        SqlDataReader reader;
        ConnectionState state = new ConnectionState();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox3.Text = "";
            TextBox2.Text = "";
            TextBox4.Text = "";
            TextBox7.Text = "";
            TextBox8.Text = "";
            TextBox9.Text = "";
            TextBox1.Text = "";
            TextBox3.Focus();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            String Time = "";

            if (state == ConnectionState.Open)
                conn.Close();
            else
            {
                conn.Open();
                query = new SqlCommand("Select * from tbl_Sch where Music_Form='" + TextBox3.Text.Trim() + "'", conn);
                reader = query.ExecuteReader();
                while (reader.Read())
                   Time=reader[8].ToString();
                reader.Close();
                conn.Close();
            }


            if (Time.Equals(Request.Form["time"].ToString()))

                Response.Write("<script>alert('Records Already Exist so please Update');</script>");


            else
            {





                if (!FileUpload1.HasFile)
                {
                    lblMessage.Visible = true;
                    lblMessage.Text = "Please Select Image File";


                }
                else
                {
                    int length = FileUpload1.PostedFile.ContentLength;
                    byte[] i = new byte[length];


                    FileUpload1.PostedFile.InputStream.Read(i, 0, length);

                    try
                    {

                        if (state == ConnectionState.Open)
                            conn.Close();
                        else
                        {
                            conn.Close();
                            conn.Open();
                            query = new SqlCommand("insert into tbl_Sch values('" + TextBox3.Text.Trim() + "','" + TextBox9.Text.Trim() + "','" + TextBox2.Text.Trim() + "',@IMG,'" + TextBox8.Text.Trim() + "','" + TextBox4.Text.Trim() + "','" + TextBox1.Text.Trim() + "','" + TextBox7.Text.Trim() + "','" + Request.Form["time"].ToString() + "')", conn);
                            query.Parameters.Add(new SqlParameter("@IMG", i));
                            reader = query.ExecuteReader();
                            lblMessage.Visible = true;
                            reader.Close();
                            lblMessage.Text = "Recods Inserted Successfully..";
                        }

                        TextBox3.Text = "";
                        TextBox2.Text = "";
                        TextBox4.Text = "";
                        TextBox7.Text = "";
                        TextBox8.Text = "";
                        TextBox9.Text = "";
                        TextBox1.Text = "";
                        TextBox3.Focus();

                    }
                    finally
                    {
                        conn.Close();
                    }
                }

            }
        }
    }
}