﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace MusicAcademy
{
    public partial class SignUp : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-U1GMOQV;Initial Catalog=MusicDb;Integrated Security=True");
        SqlCommand query;
        SqlDataReader reader;
        ConnectionState state = new ConnectionState();
        String UserN = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            Random rd = new Random();
            UserN = "ABC-" + rd.Next(4567, 9963);
            TextBox1.Text = UserN;
        }

        protected void TextBox9_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox4.Text = "";
            TextBox7.Text = "";
            TextBox8.Text = "";
            TextBox9.Text = "";
            TextBox9.Focus();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (!FileUpload1.HasFile)
            {
                lblMessage.Visible = true;
                lblMessage.Text = "Please Select Image File";


            }
            else
            {
                int length = FileUpload1.PostedFile.ContentLength;
                byte[] i = new byte[length];


                FileUpload1.PostedFile.InputStream.Read(i, 0, length);

                try
                {

                    if (state == ConnectionState.Open)
                        conn.Close();
                    else
                    {
                        conn.Close();
                        conn.Open();
                        query = new SqlCommand("insert into tbl_Stud values('" + TextBox1.Text.Trim() + "','" + TextBox9.Text.Trim() + "','" + TextBox7.Text.Trim() + "','" + TextBox2.Text.Trim() + "',@IMG,'" + TextBox8.Text.Trim() + "','" + TextBox4.Text.Trim() + "')", conn);
                        query.Parameters.Add(new SqlParameter("@IMG", i));
                        reader = query.ExecuteReader();
                        lblMessage.Visible = true;
                        reader.Close();
                        lblMessage.Text = "Recods Inserted Successfully..";
                    }
                    TextBox1.Text = "";
                    TextBox2.Text = "";
                    TextBox4.Text = "";
                    TextBox7.Text = "";
                    TextBox8.Text = "";
                    TextBox9.Text = "";
                    TextBox9.Focus();

                }
                finally
                {
                    conn.Close();
                }
            }
        }
    }
}